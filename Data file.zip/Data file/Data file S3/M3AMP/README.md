# Generation
please refer to train.sh in gen folder


# Identification
please refer to main.py for indentification