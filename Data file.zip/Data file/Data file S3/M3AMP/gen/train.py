import time

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn.functional import mse_loss
from torchmetrics.functional import pearson_corrcoef
from torchmetrics import F1Score


def mixup_criterion(criterion, pred, y_a, y_b, lam, pow=2):
    y = lam ** pow * y_a + (1 - lam) ** pow * y_b
    return criterion(pred, y)


def mixup_data(v, q, a):
    '''Returns mixed inputs, pairs of targets, and lambda without organ constraint'''
    lam = np.random.beta(1, 1)

    batch_size = v.shape[0]
    index = torch.randperm(batch_size)

    mixed_v = lam * v + (1 - lam) * v[index, :]
    mixed_q = lam * q + (1 - lam) * q[index, :]

    a_1, a_2 = a, a[index]
    return mixed_v, mixed_q, a_1, a_2, lam


def imq_kernel(X: torch.Tensor,
               Y: torch.Tensor,
               h_dim: int):
    batch_size = X.size(0)

    norms_x = X.pow(2).sum(1, keepdim=True)  # batch_size x 1
    prods_x = torch.mm(X, X.t())  # batch_size x batch_size
    dists_x = norms_x + norms_x.t() - 2 * prods_x

    norms_y = Y.pow(2).sum(1, keepdim=True)  # batch_size x 1
    prods_y = torch.mm(Y, Y.t())  # batch_size x batch_size
    dists_y = norms_y + norms_y.t() - 2 * prods_y

    dot_prd = torch.mm(X, Y.t())
    dists_c = norms_x + norms_y.t() - 2 * dot_prd

    stats = 0
    for scale in [.1, .2, .5, 1., 2., 5., 10.]:
        C = 2 * h_dim * 1.0 * scale
        res1 = C / (C + dists_x)
        res1 += C / (C + dists_y)

        if torch.cuda.is_available():
            res1 = (1 - torch.eye(batch_size).cuda()) * res1
        else:
            res1 = (1 - torch.eye(batch_size)) * res1

        res1 = res1.sum() / (batch_size - 1)
        res2 = C / (C + dists_c)
        res2 = res2.sum() * 2. / (batch_size)
        stats += res1 - res2

    return stats


def train(args, epoch, model, train_loader, valid_loader, device, criterion, optimizer):
    model.train()
    loss_record_vox_rec = 0
    loss_record_seq_rec = 0
    loss_record_gen_norm = 0
    yt = []
    start_time = time.time()
    for data in train_loader:
        voxel, seq, gt = data
        voxel = voxel.to(device)
        seq = seq.to(device)
        gt = gt.to(device)
        yt.append(gt.to(device))
        reconstruct, pred, mean, log_var, cond_z = model((voxel, seq), gt)
        vox_rec, seq_rec = reconstruct

        loss_rec_vox = F.smooth_l1_loss(vox_rec, voxel.to(device), beta=0.01, reduction='mean')
        # loss_rec_vox = F.cross_entropy(vox_rec, voxel.to(device))
        seq = seq.squeeze(1)

        # 获取每个序列的长度
        loss_rec_seq = 0
        seq = seq.squeeze(1)
        for i in range(seq_rec.shape[0]):
            length = torch.where(seq[i] >= 0)[-1][-1].item() + 1
            loss_rec_seq += F.smooth_l1_loss(seq_rec[i][:length], seq[i][:length])
        loss_rec_seq /= seq_rec.shape[0]
        loss_rec_seq /= 50

        if args.gen_model == 'vae':
            loss_KLD = -0.5 * torch.sum(1 + log_var - mean.pow(2) - log_var.exp())
            loss_norm = loss_KLD/seq_rec.shape[0]
            loss = loss_rec_vox + loss_rec_seq + loss_norm
        elif args.gen_model == 'wae':
            z_fake = torch.randn(cond_z.shape).cuda()
            mmd_loss = imq_kernel(cond_z, z_fake, h_dim=2048+64)
            loss_norm = mmd_loss/seq_rec.shape[0]
            loss = loss_rec_vox + loss_rec_seq + loss_norm
        else:
            # pred = torch.cat((out), dim=1)
            # loss = bce_loss(torch.sigmoid(pred), torch.tensor(np.asarray(data.y)).cuda().float())

            loss_pred = F.binary_cross_entropy(pred, gt.cuda().float())
            loss = loss_rec_vox + loss_rec_seq + loss_pred

        loss.backward()
        optimizer.step()
        optimizer.zero_grad()

        loss_record_vox_rec += loss_rec_vox.item()
        loss_record_seq_rec += loss_rec_seq.item()
        loss_record_gen_norm += loss_norm.item()
    print('epoch time: ' + str(time.time()-start_time)+' '+str(loss_record_vox_rec)+' '+str(loss_record_seq_rec)+' '+str(loss_record_gen_norm))
    # if epoch == 1:
    #     yt = torch.cat(yt).int()
    #     print(torch.sum(yt, 0))
    # print(var_list)
    # model.eval()
    total_valid_loss = 0
    valid_data_size = 0
    preds = []
    ys = []
    # with torch.no_grad():
    #     for data in valid_loader:
    #         voxel, seq, gt = data
    #         ys.append(gt.cuda())
    #         _, out = model((voxel.to(device), seq.to(device)))
    #         pred = out
    #         # pred = torch.cat((out), dim=1)
    #         preds.append(pred)
    # preds = torch.cat(preds, dim=0)
    # ys = torch.cat(ys).int()
    # if epoch == 1:
    #     print(torch.sum(ys, 0))

    # valid_loss = total_valid_loss / valid_data_size
    # print('preds', preds.shape)
    # print('ys', ys.shape)
    # print(preds.shape)
    # print(ys.shape)
    # valid_loss = f1s(preds, ys)
    # class_specific_f1 = f1s2f(preds, ys)
    valid_loss = 0
    class_specific_f1 = 0
    return (loss_record_vox_rec, loss_record_seq_rec, loss_record_gen_norm), valid_loss, class_specific_f1


def evaluate(args, model, loader, device, return_tensor=False):
    model.eval()
    auc_pred, auc_label = [], []
    pred = []
    y = []
    with torch.no_grad():
        for data in loader:
            data = data.to(device)
            if args.fds or args.contrast_curri:
                out, _ = model(data)
            else:
                out = model(data)
            pred.append(out)
            y.append(data.y)
            auc_pred.extend(out.cpu().numpy().reshape(-1).tolist())
            auc_label.extend(data.y.cpu().numpy().reshape(-1).tolist())

        pred_tensor = torch.cat(pred)
        y_tensor = torch.cat(y)
        corr = pearson_corrcoef(pred_tensor, y_tensor)
        rmse = torch.sqrt(mse_loss(pred_tensor, y_tensor))

    if return_tensor:
        return pred_tensor, y_tensor
    else:
        return corr, rmse
