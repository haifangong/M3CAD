import argparse
import json
import logging
import os

import numpy as np
import torch
from torch.utils.data import DataLoader

from dataset import ADataset
from loss import vae_loss
from model import PretrainVAE, PretrainWAE
from train import train


def main(args):
    criterion = vae_loss
    weight_dir = os.path.join("./runs", args.gen_model + "/" + args.feature + str(args.seed))

    print('saving_dir: ', weight_dir)
    if not os.path.exists(weight_dir):
        os.makedirs(weight_dir)
    if not os.path.exists(weight_dir+'/weights/'):
        os.makedirs(weight_dir+'/weights/')

    logging.basicConfig(handlers=[
        logging.FileHandler(filename=os.path.join(weight_dir, "training.log"), encoding='utf-8', mode='w+')],
        format="%(asctime)s %(levelname)s:%(message)s", datefmt="%F %A %T", level=logging.INFO)

    with open(os.path.join(weight_dir, "config.json"), "w") as f:
        f.write(json.dumps(vars(args)))

    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

    logging.info('Loading Test Dataset')

    best_perform_list = [[] for i in range(5)]
    f = open(weight_dir+'/file.txt', 'a+')
    for i in range(1):
        # if args.model == 'resnet26':
        #     model = resnet26(num_classes=args.classes)
        # elif args.model == 'resnet50':
        #     model = resnet50(num_classes=args.classes)
        # elif args.model == 'resnet101':
        #     model = resnet101(num_classes=args.classes)
        # elif args.model == 'resnet152':
        #     model = resnet152(num_classes=args.classes)
        # elif args.model == 'bi-gru':
        #     model = gru(input_dim=22, classes=args.classes)
        # else:
        #     raise NotImplementedError
        model = PretrainVAE(args.classes)
        if len(args.pretrain) != 0:
            model = load_pretrain_model(model, torch.load(args.pretrain))
            model.load_state_dict()
        model.to(device)

        train_set = ADataset(mode='train', fold=i)
        # test_set = ADataset(mode='valid', fold=i)
        train_loader = DataLoader(train_set, batch_size=args.batch_size, shuffle=True)
        # valid_loader = DataLoader(test_set, batch_size=args.batch_size, shuffle=False)
        optimizer = torch.optim.Adam(model.parameters())
        # optimizer = torch.optim.AdamW(model.parameters(), lr=0.001)
        # optimizer = torch.optim.SGD(model.parameters(), lr=args.lr, momentum=True, weight_decay=5e-5)

        # early_stopping = EarlyStopping(patience=args.patience, path=weights_path)
        logging.info(f'Running Cross Validation {i + 1}')

        best_train_loss = 100
        for epoch in range(1, args.epochs + 1):
            train_loss, valid_f1, class_specific_f1 = train(args, epoch, model, train_loader, train_loader, device,
                                                            criterion, optimizer)
            if sum(train_loss) < best_train_loss:
                best_train_loss = sum(train_loss)
                torch.save(model.state_dict(), weight_dir+'/weights/'+str(epoch+1)+'.pth')
            # if valid_f1 > best_f1:
            #     best_f1 = valid_f1
            #     best_perform_list[i] = np.asarray(class_specific_f1.detach().cpu())
            f.write(str(train_loss[0])+','+str(train_loss[1])+','+str(train_loss[2])+'\n')

            if epoch % 1 == 0:
                print(f'Epoch: {epoch:03d}, Train Loss: {train_loss[0]:.3f}, Valid F1: {valid_f1:.3f}')
            # print(class_specific_f1)

        logging.info(f'Fold {i + 1}, Best Valid Loss: {valid_f1:.3f}')

    logging.info(f'Cross Validation Finished!')
    best_perform_list = np.asarray(best_perform_list)
    perform = open(weight_dir + '/result-' + args.feature + '.txt', 'w')
    print(best_perform_list)
    print(np.mean(best_perform_list, 0))
    print(np.std(best_perform_list, 0))
    perform.write(np.mean(best_perform_list, 0) + '\n')
    perform.write(np.std(best_perform_list, 0) + '\n')


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='GOOD')
    parser.add_argument('--gen_model', type=str, default='vae',
                        help='vae wae ')
    parser.add_argument('--model', type=str, default='resnet26',
                        help='model resnet26, bi-gru')
    parser.add_argument('--classes', type=str, default=8,
                        help='model')
    parser.add_argument('--batch-size', type=int, dest='batch_size', default=128,
                        help='input batch size for training (default: 128)')
    parser.add_argument('--epochs', type=int, default=80,
                        help='number of epochs to train (default: 80)')
    parser.add_argument('--lr', type=float, default=0.001,
                        help='learning rate (default: 0.002)')
    parser.add_argument('--decay', type=float, default=0.0005,
                        help='weight decay (default: 0.0005)')
    parser.add_argument('--warm-steps', type=int, dest='warm_steps', default=0,
                        help='number of warm start steps for learning rate (default: 10)')
    parser.add_argument('--patience', type=int, default=10,
                        help='patience for early stopping (default: 10)')
    parser.add_argument('--loss', type=str, default='ce',
                        help='loss function (mlce, sl, mix)')

    parser.add_argument('--seed', type=int, default=1,
                        help="Seed for splitting dataset (default 1)")
    parser.add_argument('--pretrain', type=str, dest='pretrain', default='',
                        help='path of the pretrain model')  # /data2/gonghaifan/codes/3dpretrain/out/e50.pth

    # model setting
    parser.add_argument('--feature', type=str, default='vq',
                        help="v, q, vq for voxel, sequence, voxel and sequence")
    parser.add_argument('--fusion', type=str, default='1',
                        help="fusion method")

    args = parser.parse_args()

    main(args)

