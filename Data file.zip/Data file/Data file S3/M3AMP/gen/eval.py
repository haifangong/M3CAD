import time

import torch
from Bio.SeqUtils.ProtParam import ProteinAnalysis

from dataset import idx2ama
from model import Pretrain

gen = open('gen_10k_mm_v2.txt', 'w')

def calculate_charge(sequence, pH=7.2):
    protein_analysis = ProteinAnalysis(sequence)
    return protein_analysis.charge_at_pH(pH)

def estimate_alpha_helix_fraction(sequence):
    protein_analysis = ProteinAnalysis(sequence)
    helix_fraction, _, _ = protein_analysis.secondary_structure_fraction()
    return helix_fraction
def generate():
    # model = Pretrain(9).cuda()
    model = Pretrain(3).cuda()
    model.load_state_dict(torch.load('./runs/all64.pth'))
    # model.load_state_dict(torch.load('./runs-old/all50.pth'))
    # model.load_state_dict(torch.load('./runs-old/all75-mm.pth'))
    seq_cache = []
    gen_count = 1000
    count = 1
    # condition = torch.tensor([6, 6, 1, 1, 1, 1, 1, 1, 0]).long().unsqueeze(0).cuda()
    # condition = torch.tensor([1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]).long().unsqueeze(0).cuda()
    # condition = torch.tensor([6, 1, 1, 1, 1, 1, 1, 1, 1, 2]).long().unsqueeze(0).cuda()
    condition = torch.tensor([1, 1, 1]).long().unsqueeze(0).cuda()
    # condition = torch.tensor([1, 1, 1, 1]).long().unsqueeze(0).cuda()
    start = time.time()
    average_charge = 0
    average_alpha = 0
    positive_charge = 0
    while count <= gen_count:
        if count % 1000 == 0:
            print('ETA: ', time.time()-start)
        z = torch.randn([condition.size(0), 64]).cuda()
        reconstruct, pred = model.inference(z, condition)
        pred_seq = []
        print(pred)
        length = int(pred[0][0].item()) + 1
        if length < 6:
            continue
        for i in pred[0][:length]:
            idx = int(i.item())
            if idx > 20:
                idx = 20
            if idx == 0:
                break
            if idx < 0:
                break
            pred_seq.append(idx2ama[idx])
        seq_str = ''.join(pred_seq)
        print(seq_str)
        if seq_str not in seq_cache:
            seq_charge = calculate_charge(seq_str)
            print(seq_charge)
            seq_alpha = estimate_alpha_helix_fraction(seq_str)
            average_charge += calculate_charge(seq_str)
            average_alpha += seq_alpha
            if seq_charge > 3:
                positive_charge += 1
            seq_cache.append(seq_str)
            gen.write('>' + str(count) + '\n' + seq_str + '\n')
            count += 1
    print('average_charge:', average_charge/gen_count)
    print('average_alpha:', average_alpha/gen_count)
    print('better_charge:', positive_charge)

generate()
