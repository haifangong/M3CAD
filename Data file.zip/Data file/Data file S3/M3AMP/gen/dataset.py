import os
import torch
from Bio.Data.PDBData import protein_letters_3to1
from Bio.PDB import PDBParser, is_aa
from torch.utils.data import random_split, Dataset
import random
import pandas as pd
import numpy as np
import pickle
from tqdm import tqdm
from torchvision import transforms
import mdtraj as md
from Bio.SeqUtils.ProtParam import ProteinAnalysis


def clamp(n, smallest, largest):
    return sorted([smallest, n, largest])[1]


ATOMS = {'H': 1, 'C': 12, 'N': 14, 'O': 16, 'S': 30}
ATOMS_R = {'H': 1, 'C': 1.5, 'N': 1.5, 'O': 1.5, 'S': 2}
AMINO_ACID_WATER = {'A': 255, 'V': 255, 'P': 255, 'F': 255, 'W': 255, 'I': 255, 'L': 255, 'G': 155, 'M': 155,
                    'Y': 55, 'S': 55, 'T': 55, 'C': 55, 'N': 55, 'Q': 55, 'D': 55, 'E': 55, 'K': 55, 'R': 55, 'H': 55}
AMINO_ACID_CHARGE = {'D': 55, 'E': 55, 'A': 155, 'V': 155, 'P': 155, 'F': 155, 'W': 155, 'I': 155, 'L': 155, 'G': 155,
                     'M': 155, 'Y': 155, 'S': 155, 'T': 155, 'C': 155, 'N': 155, 'Q': 155, 'K': 255, 'R': 255, 'H': 255}


def pdb_parser(parser, idx, pdb_path):
    """

    """
    voxel = np.zeros((3, 64, 64, 64), dtype=np.int8)
    structure = parser.get_structure(idx, pdb_path)
    id = ''

    for i in structure[0]:
        id = i.id
    chain = structure[0][id]
    for res in chain:
        if is_aa(res.get_resname(), standard=True):
            resname = res.get_resname()
            amino = protein_letters_3to1[resname]
            ATOM_WATER = AMINO_ACID_WATER[amino]
            ATOM_CHARGE = AMINO_ACID_CHARGE[amino]
            for i in res:
                if i.id not in ATOMS.keys():
                    continue
                x, y, z = i.get_coord()
                if abs(x) > 32:
                    x = clamp(x, -31, 31)
                if abs(y) > 32:
                    y = clamp(x, -31, 31)
                if abs(z) > 32:
                    z = clamp(x, -31, 31)
                x_i, y_i, z_i = int(x) + 32, int(y) + 32, int(z) + 32
                ATOM_WEIGHT = ATOMS[i.id]
                ATOM_R = ATOMS_R[i.id]
                if ATOM_R == 1:
                    voxel[0, x_i - 1:x_i, y_i - 1:y_i, z_i - 1:z_i] = ATOM_WEIGHT
                    voxel[1, x_i - 1:x_i, y_i - 1:y_i, z_i - 1:z_i] = ATOM_WATER
                    voxel[2, x_i - 1:x_i, y_i - 1:y_i, z_i - 1:z_i] = ATOM_CHARGE
                elif ATOM_R == 1.5:
                    voxel[0, x_i - 1:x_i + 1, y_i - 1:y_i + 1, z_i - 1:z_i + 1] = ATOM_WEIGHT
                    voxel[1, x_i - 1:x_i + 1, y_i - 1:y_i + 1, z_i - 1:z_i + 1] = ATOM_WATER
                    voxel[2, x_i - 1:x_i + 1, y_i - 1:y_i + 1, z_i - 1:z_i + 1] = ATOM_CHARGE
                else:
                    voxel[0, x_i - ATOM_R: x_i + ATOM_R, x_i - ATOM_R: x_i + ATOM_R,
                    x_i - ATOM_R: x_i + ATOM_R] = ATOM_WEIGHT
                    voxel[1, x_i - ATOM_R: x_i + ATOM_R, x_i - ATOM_R: x_i + ATOM_R,
                    x_i - ATOM_R: x_i + ATOM_R] = ATOM_WATER
                    voxel[2, x_i - ATOM_R: x_i + ATOM_R, x_i - ATOM_R: x_i + ATOM_R,
                    x_i - ATOM_R: x_i + ATOM_R] = ATOM_CHARGE
    return voxel


AMAs = {'G': 20, 'A': 1, 'V': 2, 'L': 3, 'I': 4, 'P': 5, 'F': 6, 'Y': 7, 'W': 8, 'S': 9, 'T': 10, 'C': 11,
        'M': 12, 'N': 13, 'Q': 14, 'D': 15, 'E': 16, 'K': 17, 'R': 18, 'H': 19, 'X': 21}
idx2ama = {20: 'G', 1: 'A', 2: 'V', 3: 'L', 4: 'I', 5: 'P', 6: 'F', 7: 'Y', 8: 'W', 9: 'S', 10: 'T', 11: 'C',
           12: 'M', 13: 'N', 14: 'Q', 15: 'D', 16: 'E', 17: 'K', 18: 'R', 19: 'H', 21: 'X', 0: ''}


def calculate_charge(sequence, pH=7.2):
    protein_analysis = ProteinAnalysis(sequence)
    return protein_analysis.charge_at_pH(pH)


def estimate_alpha_helix(pdb_file, sequence):
    traj = md.load(pdb_file)
    secondary_structure = md.compute_dssp(traj)
    alpha_helices_count = (secondary_structure[0] == 'H').sum()
    return alpha_helices_count / len(sequence)


p = PDBParser()


class ADataset(Dataset):
    '''
    x: Features.
    y: Targets, if none, do prediction.
    '''

    def __init__(self, mode='train', fold=0):
        self.data_list = []
        all_data = pd.read_csv('./metadata/data_515.csv', encoding="unicode_escape").values
        # all_data = pd.read_csv('./metadata/data.csv', encoding="unicode_escape").values
        # 0-13 anti 2-13 specific [763 5619 5227 1156 4504 14 1561 0 9 95 0 138]
        # 14-20 toxic
        # 21-24 machine
        print(all_data.shape)
        # all_data = all_data[:13346]
        # all_data = all_data[:256]
        idx_list, seq_list, labels = all_data[:, 0], all_data[:, 1], all_data[:, 2:]
        filter_data = []
        # label_list = np.concatenate((labels[:, 1:2], labels[:, -2:]), axis=1)
        label_list = np.concatenate((labels[:, 1:2], labels[:, 2:7], labels[:, 8:9]), axis=1)
        for idx in range(len(idx_list)):
            seq = seq_list[idx].upper().strip()
            # print(label_list[idx])
            gt = []
            # DR_number, gram_1, gram_2 = label_list[idx]
            # gt.append(1) if int(DR_number > 1) else gt.append(0)
            # gt.append(1) if int(gram_1 + gram_2) == 2 else gt.append(0)
            gt = [int(i) for i in label_list[idx]]
            filter_data.append((seq, gt, str(idx_list[idx])))
        print("Fliter data finished ", len(filter_data))
        splited_data = filter_data
        count_charge_p = 0
        count_charge_pp = 0
        count_alpha = 0
        for item in tqdm(splited_data):
            seq, gt, idx = item
            idx = str(idx).zfill(5)
            # print(seq)
            if os.path.exists("../identification/pdb/pdbs/" + seq + "_relaxed_rank_1_model_3.pdb"):
                pdb_path = "../identification/pdb/pdbs/" + seq + "_relaxed_rank_1_model_3.pdb"
            elif os.path.exists("../identification/pdb/pdbs/" + seq + "_real.pdb"):
                pdb_path = "../identification/pdb/pdbs/" + seq + "_real.pdb"
            else:
                print(seq)
                assert os.path.exists("./pdb/pdbs/" + seq + "_real.pdb")
            voxel = pdb_parser(p, idx, pdb_path)
            charge = calculate_charge(seq)
            alpha_helix = estimate_alpha_helix(pdb_path, seq)
            if charge < 0:
                gt.append(0)
            elif 0 <= charge < 3:
                gt.append(1)
            elif 3 <= charge:
                gt.append(2)

            # gt.append(1) if charge/len(seq) > 0.1 else gt.append(0)
            # gt.append(1) if alpha_helix > 0.1 else gt.append(0)
            if charge > 0.5:
                count_charge_p += 1
                if charge > 4:
                    count_charge_pp += 1
            if alpha_helix > 0.5:
                count_alpha += 1
            # print(charge)
            # print(alpha_helix)
            seq_code = [AMAs[char] for char in seq]
            # if len(seq_code) == 50:
            #     seq_code[-1] = len(seq_code)*3+30
            # else:
            #     seq_code.append(len(seq_code)*3+30)
            if len(seq_code) == 50:
                seq_code[0] = len(seq_code)
            else:
                seq_code.insert(0, len(seq_code))
            # print(seq_code)
            seq_emb = [seq_code + [-1] * (50 - len(seq_code))]

            # print(gt)
            self.data_list.append((voxel, seq_emb, gt))
        # print(count_charge_p)
        # print(count_charge_pp)
        # print(count_alpha)
        self.im_aug = transforms.Compose([
            transforms.RandomHorizontalFlip(p=0.5),
            transforms.RandomVerticalFlip(p=0.5),
            transforms.RandomRotation(90, expand=False, center=None),
        ])

    def __getitem__(self, idx):
        voxel, seq, gt = self.data_list[idx]
        voxel = self.im_aug(torch.Tensor(voxel).float())
        return voxel, torch.Tensor(seq), torch.Tensor(gt)

    def __len__(self):
        return len(self.data_list)


def estimate_alpha_helix_fraction(sequence):
    protein_analysis = ProteinAnalysis(sequence)
    helix_fraction, _, _ = protein_analysis.secondary_structure_fraction()
    return helix_fraction

# 'IRILKWLL'
# Example usage:
# alpha_helix_fraction = estimate_alpha_helix_fraction('ATFGRCRRWWAALGACRR')
# print(alpha_helix_fraction)
# charge = calculate_charge('ATFGRCRRWWAALGACRR')
# print(charge)

# ADataset(mode='train', fold=0)
