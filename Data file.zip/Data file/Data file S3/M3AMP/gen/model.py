import random

import torch
import torch.nn as nn
from torchvision import transforms


class BasicBlock(nn.Module):
    expansion = 1

    def __init__(self, in_channels, channels, stride=1):
        super().__init__()

        self.conv1 = nn.Conv3d(in_channels, channels, kernel_size=3, stride=stride, padding=1, bias=False)
        self.bn1 = nn.BatchNorm3d(channels)
        self.relu = nn.ReLU(inplace=True)

        self.conv2 = nn.Conv3d(channels, channels, kernel_size=3, stride=1, padding=1, bias=False)
        self.bn2 = nn.BatchNorm3d(channels)

        self.downsample = nn.Sequential()
        if stride != 1 or in_channels != channels * self.expansion:
            self.downsample = nn.Sequential(
                nn.Conv3d(in_channels, channels * self.expansion, kernel_size=1, stride=stride, bias=False),
                nn.BatchNorm3d(channels * self.expansion)
            )

        self.stride = stride

    def forward(self, x):
        shortcut = self.downsample(x)

        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)

        out = self.conv2(out)
        out = self.bn2(out)

        out += shortcut
        out = self.relu(out)

        return out


class Bottleneck(nn.Module):
    expansion = 4

    def __init__(self, in_channels, channels, stride=1):
        super().__init__()

        self.conv1 = nn.Conv3d(in_channels, channels, kernel_size=1, bias=False)
        self.bn1 = nn.BatchNorm3d(channels)
        self.relu = nn.ReLU(inplace=True)

        self.conv2 = nn.Conv3d(channels, channels, kernel_size=3, stride=stride, padding=1, bias=False)
        self.bn2 = nn.BatchNorm3d(channels)

        self.conv3 = nn.Conv3d(channels, channels * self.expansion, kernel_size=1, bias=False)
        self.bn3 = nn.BatchNorm3d(channels * self.expansion)

        self.downsample = nn.Sequential()
        if stride != 1 or in_channels != channels * self.expansion:
            self.downsample = nn.Sequential(
                nn.Conv3d(in_channels, channels * self.expansion, kernel_size=1, stride=stride, bias=False),
                nn.BatchNorm3d(channels * self.expansion)
            )

    def forward(self, x):
        shortcut = self.downsample(x)

        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)

        out = self.conv2(out)
        out = self.bn2(out)
        out = self.relu(out)

        out = self.conv3(out)
        out = self.bn3(out)

        out += shortcut
        out = self.relu(out)

        return out


class ResNet3D(nn.Module):
    def __init__(self, block, layers, num_classes, latent_size=64):
        super().__init__()
        self.csn = nn.Linear(num_classes, 1)
        self.in_channels = 64
        self.conv1 = nn.Conv3d(3, 64, kernel_size=(7, 7, 7), stride=(2, 2, 2), padding=(3, 3, 3))  # 第一个原来是3
        self.bn1 = nn.BatchNorm3d(64)
        self.relu = nn.ReLU(inplace=True)
        self.max_pool = nn.MaxPool3d(kernel_size=(3, 3, 3), stride=(2, 2, 2), padding=(1, 1, 1))

        self.layer1 = self._make_layer(block, 64, layers[0], stride=1)
        self.layer2 = self._make_layer(block, 128, layers[1], stride=2)
        self.layer3 = self._make_layer(block, 256, layers[2], stride=2)
        self.layer4 = self._make_layer(block, 512, layers[3], stride=2)

        self.avg_pool = nn.AdaptiveAvgPool3d(1)
        self.seq_fc = nn.Sequential(nn.Linear(50, 256), nn.ReLU(), nn.Linear(256, 64))

        self.fc = nn.Linear(512 * block.expansion + 64, 3)
        self.rnn = nn.GRU(  # if use nn.RNN(), it hardly learns
            input_size=20,
            hidden_size=64,  # rnn hidden unit
            num_layers=1,  # number of rnn layer
            batch_first=True,  # input & output will has batch size as 1s dimension. e.g. (batch, time_step, input_size)
            bidirectional=True
        )
        # initialize
        for m in self.modules():
            if isinstance(m, nn.Conv3d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
            elif isinstance(m, nn.BatchNorm3d):
                m.weight.data.fill_(1)
                m.bias.data.zero_()
        self.im_aug = transforms.Compose([
            transforms.RandomHorizontalFlip(p=0.5),
            transforms.RandomVerticalFlip(p=0.5),
            transforms.RandomRotation(3, expand=False, center=None),
            # transforms.ColorJitter(brightness=0.5, contrast=0.5, hue=0.5),
            # transforms.RandomCrop(256),
            # transforms.Resize((512,512))
        ])

    def _make_layer(self, block, channels, n_blocks, stride=1):
        assert n_blocks > 0, "number of blocks should be greater than zero"
        layers = []
        layers.append(block(self.in_channels, channels, stride))
        self.in_channels = channels * block.expansion
        for i in range(1, n_blocks):
            layers.append(block(self.in_channels, channels))

        return nn.Sequential(*layers)

    def forward(self, x, y, debug=False):
        out_list = []
        # y_ = torch.sigmoid(self.csn(y))
        y_ = self.csn(y)
        voxel, seq = x

        # add conditional information
        y_ = y_.unsqueeze(1).unsqueeze(2).unsqueeze(3)  # 根据voxel的维度，你可能需要更多或者更少的unsqueeze
        voxel = voxel * y_

        # adding random noisy
        voxel = voxel + (0.1 ** 0.5) * torch.randn(voxel.shape).cuda()
        for i in range(voxel.shape[0]):
            voxel[i, ...] = self.im_aug(voxel[i])
            for j in range(50):
                if seq[i, 0, j] == -1:
                    break
                if random.random() < 0.2:
                    seq[i, 0, j] = 0
        # print(voxel.shape)
        out = self.conv1(voxel)
        out = self.bn1(out)
        out = self.relu(out)
        out_list.append(out)
        if debug:
            print("shape1:", out.shape)
        out = self.max_pool(out)
        if debug:
            print("shape2:", out.shape)

        out = self.layer1(out)
        out_list.append(out)
        if debug:
            print("shape3:", out.shape)
        out = self.layer2(out)
        out_list.append(out)
        if debug:
            print("shape4:", out.shape)
        out = self.layer3(out)
        if debug:
            print("shape5:", out.shape)
        out = self.layer4(out)
        if debug:
            print("shape6:", out.shape)

        out = self.avg_pool(out)
        if debug:
            print("shape7:", out.shape)
        out_list.append(out)

        out = out.view(out.size(0), -1)
        feature = out
        seq = self.seq_fc(seq).squeeze(1)
        fusion = torch.cat((seq, feature), dim=1)
        out_list.append(fusion)
        out = self.fc(fusion)
        out_list.append(out)
        return out_list
        # out2 = nn.functional.softmax(out, dim=1)  # 后加的

        # return out2, feature


def resnet26(num_classes):
    return ResNet3D(Bottleneck, [1, 2, 4, 1], num_classes=num_classes)


def resnet50(num_classes):
    return ResNet3D(Bottleneck, [3, 4, 6, 3], num_classes=num_classes)


def resnet101(num_classes):
    return ResNet3D(Bottleneck, [3, 4, 23, 3], num_classes=num_classes)


def resnet152(num_classes):
    return ResNet3D(Bottleneck, [3, 8, 36, 3], num_classes=num_classes)


class Decoder(nn.Module):
    def __init__(self):
        super().__init__()
        self.seq_fc = nn.Sequential(nn.Linear(64, 256), nn.ReLU(), nn.Linear(256, 50))

        self.up_conv1 = nn.Sequential(
            nn.ConvTranspose3d(2048, 2048, 2, 2),
            nn.PReLU(2048)
        )

        self.up_conv2 = nn.Sequential(
            nn.ConvTranspose3d(2048, 1024, 2, 2),
            nn.PReLU(1024)
        )

        self.up_conv3 = nn.Sequential(
            nn.ConvTranspose3d(1024, 512, 2, 2),
            nn.PReLU(512)
        )

        self.up_conv4 = nn.Sequential(
            nn.ConvTranspose3d(512, 256, 2, 2),
            nn.PReLU(256)
        )

        self.up_conv5 = nn.Sequential(
            nn.ConvTranspose3d(256, 64, 2, 2),
            nn.PReLU(64)
        )
        self.up_conv6 = nn.Sequential(
            nn.ConvTranspose3d(64, 3, 2, 2),
        )

    def forward(self, x):
        vox, seq = x[:, :2048], x[:, 2048:]
        up1 = self.up_conv1(vox)
        # print(up1.shape)
        # print(up2.shape)
        up2 = self.up_conv2(up1)
        # print(up2.shape)
        # print(up1.shape)
        # print(level1.shape)
        up3 = self.up_conv3(up2)
        # print(up3.shape)
        # print(result.shape)
        up4 = self.up_conv4(up3)
        up5 = self.up_conv5(up4)
        up6 = self.up_conv6(up5)
        # up7 = self.up_conv7(up6)
        seq_f = self.seq_fc(seq.view(seq.shape[0], -1))
        return up6, seq_f

class PretrainWAE(nn.Module):
    def __init__(self, classes, latent_size=64):
        super().__init__()
        self.encoder = resnet26(classes)
        self.decoder = Decoder()
        self.csn = nn.Linear(64 + classes, 2048 + 64)
        self.linear_means = nn.Linear(2048 + 64, latent_size)
        self.linear_log_var = nn.Linear(2048 + 64, latent_size)

    def reparameterize(self, mu, log_var):
        std = torch.exp(0.5 * log_var)
        eps = torch.randn_like(std)
        return mu + eps * std

    def inference_temp(self, x, z, c):
        batch_size = x[0].shape[0]
        features = self.encoder(x, c)
        mean = self.linear_means(features[-2].view(batch_size, -1))
        var = 0
        z += mean
        cond_f = self.csn(torch.cat((z, c), dim=-1))
        recon_x = self.decoder(cond_f.view(1, 2048 + 64, 1, 1, 1))
        return recon_x


    def forward(self, x, y):
        batch_size = x[0].shape[0]
        features = self.encoder(x, y)
        mean = self.linear_means(features[-2].view(batch_size, -1))
        var = 0
        z = mean
        cond_f = self.csn(torch.cat((z, y), dim=-1))
        result = self.decoder(cond_f.view(batch_size, 2048 + 64, 1, 1, 1))
        prediction = features[-1]
        return result, prediction, mean, var, cond_f



class PretrainVAE(nn.Module):
    def __init__(self, classes, latent_size=64):
        super().__init__()
        self.encoder = resnet26(classes)
        self.decoder = Decoder()
        self.csn = nn.Linear(64 + classes, 2048 + 64)
        self.linear_means = nn.Linear(2048 + 64, latent_size)
        self.linear_log_var = nn.Linear(2048 + 64, latent_size)

    def reparameterize(self, mu, log_var):
        std = torch.exp(0.5 * log_var)
        eps = torch.randn_like(std)
        return mu + eps * std

    def inference(self, z, c):
        cond_f = self.csn(torch.cat((z, c), dim=-1))
        recon_x = self.decoder(cond_f.view(1, 2048 + 64, 1, 1, 1))
        return recon_x

    def forward(self, x, y):
        batch_size = x[0].shape[0]
        features = self.encoder(x, y)
        mean = self.linear_means(features[-2].view(batch_size, -1))
        var = self.linear_log_var(features[-2].view(batch_size, -1))
        z = self.reparameterize(mean, var)

        cond_f = self.csn(torch.cat((z, y), dim=-1))
        result = self.decoder(cond_f.view(batch_size, 2048 + 64, 1, 1, 1))
        prediction = features[-1]
        return result, prediction, mean, var, cond_f


if __name__ == "__main__":
    number_classes = 3
    gt = torch.zeros((16, number_classes))
    p = PretrainVAE(number_classes)
    # resnet = resnet26(3).cuda()
    input_voxel = torch.zeros((16, 3, 64, 64, 64))
    # out_put = resnet((input_voxel, torch.zeros((16, 50)).cuda()))
    # print()
    result, pred = p((input_voxel, torch.zeros((16, 50))), gt)
    print(result.shape)
    print(pred.shape)
