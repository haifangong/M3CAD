CUDA_VISIBLE_DEVICES=0 python main.py --epochs 150

